<html>
<head>
</head>
<body>
<div class = "navbar navbar-default navbar-static-top" role="navigation">
		<!--<div class = "container">-->
			
			<div class = "nav navbar-nav navbar-left">
      			<li><a href ="ahome.php" class = "navbar-brand"><img width=120 height=35 src="img/mowlogogreen.png"></a></li>
	      		<button class = "navbar-toggle" data-toggle = "collapse" data-target = ".navHeaderCollapse">
					<span class = "icon-bar"></span>
					<span class = "icon-bar"></span>
					<span class = "icon-bar"></span>
				</button>
       		</div>
			<div class = "navmenu">
				<div class = "collapse navbar-collapse navHeaderCollapse" scrollbar="hidden">

				<ul class = "nav navbar-nav navbar-right">
					<li><a href="ahome.php">Home</a></li>
					<li><a href="#">Deliveries</a></li>
                    <li><a href="#">Clients</a></li>
                    <li><a href="#">Drivers</a></li>
                    <li><a href="#">Reports</a></li>
                    <li><a href="#">Account</a></li>
					<li><a href="alogout.php">Logout</a></li>
				</ul>
				</div>
			</div>
		<!--</div>-->
	</div>
</body>
</html>