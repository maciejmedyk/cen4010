#Bug-Masters: M-O-W Delivery
~~

Project Owner: Roxana

Scrum Master: Maciej

Team: Andrews, Maciej, Nick, Roxana, Fahad

~~

