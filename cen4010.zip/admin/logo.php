<div class="navbar-header">
	<button type="button"
	data-toggle="collapse"
	data-target=".sidebar-collapse"
	class="navbar-toggle">
		<span class="sr-only">
			Toggle navigation
		</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	</button>
	<a id="logo" href="index.php" class="navbar-brand">
		<span class="fa fa-rocket"></span>
		<span class="logo-text">MOW Admin</span>
		<span style="display: none" class="logo-text-icon">�</span>
	</a>
</div>