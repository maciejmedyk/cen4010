<ul class="nav navbar navbar-top-links navbar-right mbn">
	<li class="dropdown topbar-user">
		<a>
			<span class="hidden-xs"><?php echo $login_name; ?></span>&nbsp;
		</a>
		
	</li>
	<li>
		<a href="logout.php"><i class="fa fa-key"></i>Log Out</a>
	</li>
	
	
</ul>